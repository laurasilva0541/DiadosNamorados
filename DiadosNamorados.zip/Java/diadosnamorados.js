const contador = document.getElementById('contador');

// Defina a data de início do relacionamento
const inicioRelacionamento = new Date("2021-12-08T00:00:00");

function atualizarContador() {
    const agora = new Date();
    let diferenca = agora - inicioRelacionamento;

    const anos = Math.floor(diferenca / (1000 * 60 * 60 * 24 * 365));
    diferenca %= (1000 * 60 * 60 * 24 * 365);

    const meses = Math.floor(diferenca / (1000 * 60 * 60 * 24 * 30));
    diferenca %= (1000 * 60 * 60 * 24 * 30);

    const dias = Math.floor(diferenca / (1000 * 60 * 60 * 24));
    diferenca %= (1000 * 60 * 60 * 24);

    const horas = Math.floor(diferenca / (1000 * 60 * 60));
    diferenca %= (1000 * 60 * 60);

    const minutos = Math.floor(diferenca / (1000 * 60));
    diferenca %= (1000 * 60);

    const segundos = Math.floor(diferenca / 1000);

    // Calcula o total de dias desde o início do relacionamento
    const totalDias = Math.floor((agora - inicioRelacionamento) / (1000 * 60 * 60 * 24));

    // Atualiza o texto do contador incluindo o total de dias
    contador.textContent = 
      `${anos} anos, ${meses} meses, ${dias} dias, ${horas} horas, ${minutos} minutos e ${segundos} segundos\n` +
      `Total de dias desde o início: ${totalDias} dias❣️`;
}

setInterval(atualizarContador, 1000);
atualizarContador();

// Função para criar e subir os emojis
function criarEmoji() {
  const emoji = document.createElement('div');
  emoji.classList.add('emoji');

  // Você pode alterar o emoji ❤️ para outro se quiser
  emoji.textContent = '❤️';

  // Posição aleatória na tela
  emoji.style.left = Math.random() * 100 + 'vw';

  // Tamanho aleatório
  emoji.style.fontSize = Math.random() * 20 + 20 + 'px';

  // Animação com duração aleatória
  emoji.style.animationDuration = (Math.random() * 2 + 3) + 's';

  document.body.appendChild(emoji);

  // Remover após a animação
  setTimeout(() => {
    emoji.remove();
  }, 6000);
}

// Criar emojis em intervalos
setInterval(criarEmoji, 300);


